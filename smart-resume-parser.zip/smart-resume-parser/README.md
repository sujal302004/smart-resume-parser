# Smart Resume Parser

A comprehensive resume parsing system that extracts structured information from PDF and DOCX resumes using NLP and pattern matching.

## Features

- 📄 Extract text from PDF and DOCX files
- 🔍 Parse personal information (name, email, phone)
- 💼 Identify skills and competencies
- 🎓 Extract education history
- 💼 Parse work experience
- 📊 Interactive Streamlit UI
- 📁 Batch processing support
- 📤 Export to JSON and CSV formats

## Installation

1. Clone or download this project
2. Install required packages:
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm