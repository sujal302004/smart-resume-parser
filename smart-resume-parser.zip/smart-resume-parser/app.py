import streamlit as st # type: ignore
import pandas as pd # type: ignore
import json
import os
from datetime import datetime
from resume_parser import SmartResumeParser
import base64

# ADD THESE IMPORTS
from utils import calculate_resume_score, export_to_excel, skill_categorizer

# Page configuration
st.set_page_config(
    page_title="Smart Resume Parser",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        padding: 15px;
        margin: 10px 0;
    }
    .info-box {
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        border-radius: 5px;
        padding: 15px;
        margin: 10px 0;
    }
    .score-high { color: #28a745; font-weight: bold; }
    .score-medium { color: #ffc107; font-weight: bold; }
    .score-low { color: #dc3545; font-weight: bold; }
</style>
""", unsafe_allow_html=True)

def main():
    st.markdown('<div class="main-header">📄 Smart Resume Parser</div>', unsafe_allow_html=True)
    
    # Initialize parser
    @st.cache_resource
    def load_parser():
        return SmartResumeParser()
    
    parser = load_parser()
    
    # Sidebar
    st.sidebar.title("Navigation")
    app_mode = st.sidebar.selectbox("Choose Mode", 
                                   ["Single Resume Parser", "Batch Processing", "Test Results"])
    
    if app_mode == "Single Resume Parser":
        single_resume_parser(parser)
    elif app_mode == "Batch Processing":
        batch_processing(parser)
    else:
        test_results()

def single_resume_parser(parser):
    st.header("Upload Single Resume")
    
    uploaded_file = st.file_uploader("Choose a resume file", type=['pdf', 'docx'])
    
    if uploaded_file is not None:
        # Save uploaded file temporarily
        file_path = f"temp_{uploaded_file.name}"
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        try:
            with st.spinner("Parsing resume... This may take a few seconds."):
                parsed_data = parser.parse_resume(file_path)
            
            if 'error' in parsed_data:
                st.error(f"Error parsing resume: {parsed_data['error']}")
            else:
                display_results(parsed_data, uploaded_file.name, parser)
                
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")
        finally:
            # Clean up temporary file
            if os.path.exists(file_path):
                os.remove(file_path)

def batch_processing(parser):
    st.header("Batch Process Multiple Resumes")
    
    uploaded_files = st.file_uploader("Choose multiple resume files", 
                                     type=['pdf', 'docx'], 
                                     accept_multiple_files=True)
    
    if uploaded_files and st.button("Process All Resumes"):
        all_data = []
        progress_bar = st.progress(0)
        
        for i, uploaded_file in enumerate(uploaded_files):
            # Update progress
            progress = (i + 1) / len(uploaded_files)
            progress_bar.progress(progress)
            
            # Save and process each file
            file_path = f"temp_{uploaded_file.name}"
            with open(file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            try:
                parsed_data = parser.parse_resume(file_path)
                if 'error' not in parsed_data:
                    # Add filename to data
                    parsed_data['filename'] = uploaded_file.name
                    all_data.append(parsed_data)
                
            except Exception as e:
                st.warning(f"Failed to process {uploaded_file.name}: {str(e)}")
            finally:
                if os.path.exists(file_path):
                    os.remove(file_path)
        
        if all_data:
            display_batch_results(all_data, parser)

def test_results():
    st.header("Test Resumes Results")
    st.info("This section would display pre-processed test resume results.")
    
    # Create sample test resumes directory structure
    if st.button("Generate Sample Test Data"):
        create_sample_test_data()

def display_results(parsed_data, filename, parser):
    st.markdown(f'<div class="success-box">✅ Successfully parsed: {filename}</div>', unsafe_allow_html=True)
    
    # ADD RESUME SCORE AT THE TOP
    resume_score = parsed_data.get('resume_score', calculate_resume_score(parsed_data))
    
    # Color code the score
    if resume_score >= 80:
        score_class = "score-high"
    elif resume_score >= 60:
        score_class = "score-medium"
    else:
        score_class = "score-low"
    
    st.markdown(f'<div class="{score_class}" style="text-align: center; font-size: 1.5rem; margin: 20px 0;">Resume Score: {resume_score}/100</div>', unsafe_allow_html=True)
    
    # Create tabs for different views - ADDED NEW TAB FOR SKILL CATEGORIES
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["📊 Overview", "👤 Personal Info", "💼 Skills", "📂 Skill Categories", "🎓 Education", "💼 Experience"])
    
    with tab1:
        col1, col2, col3, col4 = st.columns(4)  # ADDED EXTRA COLUMN FOR SCORE
        with col1:
            st.metric("Skills Found", len(parsed_data['skills']))
        with col2:
            st.metric("Education Entries", len(parsed_data['education']))
        with col3:
            st.metric("Experience Entries", len(parsed_data['experience']))
        with col4:
            st.metric("Resume Score", f"{resume_score}/100")
        
        # Quick overview
        st.subheader("Quick Overview")
        if parsed_data['personal_info']['name']:
            st.write(f"**Name:** {parsed_data['personal_info']['name']}")
        if parsed_data['personal_info']['email']:
            st.write(f"**Email:** {parsed_data['personal_info']['email']}")
        if parsed_data.get('years_experience'):
            st.write(f"**Years of Experience:** {parsed_data['years_experience']}")
    
    with tab2:
        st.subheader("Personal Information")
        personal_info = parsed_data['personal_info']
        st.json(personal_info)
    
    with tab3:
        st.subheader("Extracted Skills")
        if parsed_data['skills']:
            # Display skills as chips
            cols = st.columns(4)
            for i, skill in enumerate(parsed_data['skills']):
                with cols[i % 4]:
                    st.markdown(f"<div style='background-color: #e0e0e0; padding: 5px 10px; border-radius: 15px; text-align: center; margin: 5px;'>{skill.title()}</div>", 
                               unsafe_allow_html=True)
        else:
            st.warning("No skills detected.")
    
    # ADD NEW TAB FOR SKILL CATEGORIES
    with tab4:
        st.subheader("Skill Categories")
        skill_categories = parsed_data.get('skill_categories', skill_categorizer(parsed_data['skills']))
        
        if skill_categories:
            for category, skills in skill_categories.items():
                if skills:  # Only show categories that have skills
                    with st.expander(f"{category.replace('_', ' ').title()} ({len(skills)} skills)"):
                        cols = st.columns(3)
                        for i, skill in enumerate(skills):
                            with cols[i % 3]:
                                st.markdown(f"<div style='background-color: #d4edda; padding: 5px 10px; border-radius: 15px; text-align: center; margin: 5px;'>{skill.title()}</div>", 
                                           unsafe_allow_html=True)
        else:
            st.info("No skill categories available.")
    
    with tab5:
        st.subheader("Education History")
        for i, edu in enumerate(parsed_data['education']):
            with st.expander(f"Education {i+1}"):
                st.write(f"**Institution:** {edu['institution']}")
                if edu['degree']:
                    st.write(f"**Degree:** {edu['degree']}")
                if edu['year']:
                    st.write(f"**Year:** {edu['year']}")
    
    with tab6:
        st.subheader("Work Experience")
        for i, exp in enumerate(parsed_data['experience']):
            with st.expander(f"Experience {i+1}"):
                st.write(f"**Company:** {exp['company']}")
                st.write(f"**Position:** {exp['position']}")
                if exp['duration']:
                    st.write(f"**Duration:** {exp['duration']}")
    
    # Export options - ENHANCED WITH EXCEL
    st.markdown("---")
    st.subheader("Export Results")
    
    col1, col2, col3, col4 = st.columns(4)  # ADDED EXTRA COLUMN FOR EXCEL
    
    with col1:
        if st.button("Export to JSON"):
            json_data = parser.to_json(parsed_data)
            st.download_button(
                label="Download JSON",
                data=json_data,
                file_name=f"parsed_resume_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
    
    with col2:
        if st.button("Export to CSV"):
            df = parser.to_dataframe(parsed_data)
            csv_data = df.to_csv(index=False)
            st.download_button(
                label="Download CSV",
                data=csv_data,
                file_name=f"parsed_resume_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col3:
        # ADD EXCEL EXPORT
        if st.button("Export to Excel"):
            excel_filename = f"resume_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            excel_file = export_to_excel([parsed_data], excel_filename)
            with open(excel_file, "rb") as f:
                st.download_button(
                    label="Download Excel",
                    data=f,
                    file_name=excel_filename,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
    
    with col4:
        # Raw text preview
        with st.expander("View Raw Text Preview"):
            st.text_area("Extracted Text", parsed_data['raw_text_preview'], height=200)

def display_batch_results(all_data, parser):
    st.header("Batch Processing Results")
    
    # Create summary DataFrame
    summary_data = []
    for data in all_data:
        summary_data.append({
            'Filename': data.get('filename', 'Unknown'),
            'Name': data['personal_info']['name'] or 'Not detected',
            'Email': data['personal_info']['email'] or 'Not detected',
            'Phone': data['personal_info']['phone'] or 'Not detected',
            'Skills Count': len(data['skills']),
            'Education Count': len(data['education']),
            'Experience Count': len(data['experience']),
            # ADD NEW COLUMNS
            'Resume Score': data.get('resume_score', calculate_resume_score(data)),
            'Years Experience': data.get('years_experience', 0)
        })
    
    summary_df = pd.DataFrame(summary_data)
    st.dataframe(summary_df, use_container_width=True)
    
    # ADD BATCH EXCEL EXPORT
    st.subheader("Export Batch Results")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Export All as JSON"):
            export_data = {
                'timestamp': datetime.now().isoformat(),
                'total_resumes': len(all_data),
                'results': all_data
            }
            json_data = json.dumps(export_data, indent=2)
            
            st.download_button(
                label="Download JSON Batch Results",
                data=json_data,
                file_name=f"batch_resumes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
    
    with col2:
        if st.button("Export Summary as CSV"):
            st.download_button(
                label="Download CSV Summary",
                data=summary_df.to_csv(index=False),
                file_name=f"resume_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col3:
        # ADD BATCH EXCEL EXPORT
        if st.button("Export Complete Excel"):
            excel_filename = f"batch_resumes_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            excel_file = export_to_excel(all_data, excel_filename)
            with open(excel_file, "rb") as f:
                st.download_button(
                    label="Download Excel Report",
                    data=f,
                    file_name=excel_filename,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )

def create_sample_test_data():
    """Create sample test resumes for demonstration"""
    sample_resumes = [
        {
            "filename": "john_doe_software_engineer.pdf",
            "content": "John Doe\nSoftware Engineer\njohn.doe@email.com\n(555) 123-4567\n\nSKILLS\nPython, JavaScript, React, Node.js, AWS, Docker, SQL\n\nEDUCATION\nBachelor of Science in Computer Science\nUniversity of Technology, 2018-2022\nGPA: 3.8\n\nEXPERIENCE\nSenior Software Engineer\nTech Solutions Inc.\nJan 2022 - Present\n- Developed web applications using React and Node.js\n- Implemented CI/CD pipelines with Docker and AWS"
        },
        {
            "filename": "jane_smith_data_scientist.docx", 
            "content": "Jane Smith\nData Scientist\njane.smith@email.com\n(555) 987-6543\n\nSKILLS\nPython, Machine Learning, SQL, TensorFlow, PyTorch, Data Analysis\n\nEDUCATION\nMaster of Science in Data Science\nData University, 2020-2022\nBachelor of Science in Statistics\nState College, 2016-2020\n\nEXPERIENCE\nData Scientist\nAnalytics Corp\nMar 2022 - Present\n- Built ML models for predictive analytics\n- Conducted data analysis using Python and SQL"
        }
    ]
    
    st.success("Sample test data created! (This would generate actual files in a real implementation)")

if __name__ == "__main__":
    main()