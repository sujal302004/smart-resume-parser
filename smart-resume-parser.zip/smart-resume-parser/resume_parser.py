import re
import json
import fitz  # type: ignore # PyMuPDF
from docx import Document # type: ignore
import spacy # type: ignore
from typing import Dict, List, Optional
import pandas as pd # type: ignore

# ADD THESE IMPORTS
from utils import (
    clean_phone_number,
    validate_email,
    skill_categorizer,
    calculate_resume_score,
    format_duration,
    extract_years_of_experience
)


class SmartResumeParser:
    def __init__(self):
        # Load spaCy model
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            raise Exception("Please download the spaCy model: python -m spacy download en_core_web_sm")
        
        # Define skill patterns
        self.skill_patterns = [
            r'\b(python|java|c\+\+|javascript|typescript|html|css|react|angular|vue|node\.js)\b',
            r'\b(machine learning|deep learning|ai|artificial intelligence|nlp|computer vision)\b',
            r'\b(sql|mysql|postgresql|mongodb|database|nosql)\b',
            r'\b(aws|azure|gcp|cloud|docker|kubernetes|devops)\b',
            r'\b(project management|agile|scrum|jira|git|github|gitlab)\b',
            r'\b(communication|leadership|problem solving|teamwork|analytical)\b'
        ]
        
        # Education patterns
        self.education_patterns = [
            r'\b(bachelor|b\.s\.|b\.a\.|bs|ba)\b',
            r'\b(master|m\.s\.|m\.a\.|ms|ma)\b',
            r'\b(phd|doctorate|doctoral)\b',
            r'\b(university|college|institute|school)\b',
            r'\b(gpa|grade point average)\b'
        ]

    def extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text from PDF file using PyMuPDF"""
        try:
            doc = fitz.open(file_path)
            text = ""
            for page in doc:
                text += page.get_text()
            doc.close()
            return text
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")

    def extract_text_from_docx(self, file_path: str) -> str:
        """Extract text from DOCX file"""
        try:
            doc = Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text
        except Exception as e:
            raise Exception(f"Error reading DOCX: {str(e)}")

    def extract_text(self, file_path: str) -> str:
        """Extract text based on file type"""
        if file_path.lower().endswith('.pdf'):
            return self.extract_text_from_pdf(file_path)
        elif file_path.lower().endswith('.docx'):
            return self.extract_text_from_docx(file_path)
        else:
            raise ValueError("Unsupported file format. Please use PDF or DOCX.")

    def clean_text(self, text: str) -> str:
        """Clean and preprocess extracted text"""
        # Remove extra whitespace and newlines
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s\.\,\-\@]', '', text)
        return text.strip()

    def extract_name(self, text: str) -> Optional[str]:
        """Extract candidate name using spaCy NER"""
        doc = self.nlp(text[:1000])  # Process first 1000 chars for efficiency
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                return ent.text
        return None

    def extract_email(self, text: str) -> Optional[str]:
        """Extract email address"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        match = re.search(email_pattern, text)
        if match:
            email = match.group()
            # ADD VALIDATION
            if validate_email(email):
                return email
        return None

    def extract_phone(self, text: str) -> Optional[str]:
        """Extract phone number"""
        phone_patterns = [
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            r'\b\(\d{3}\)\s*\d{3}[-.]?\d{4}\b',
            r'\b\d{3}\s\d{3}\s\d{4}\b'
        ]
        for pattern in phone_patterns:
            match = re.search(pattern, text)
            if match:
                # USE THE UTILITY FUNCTION
                return clean_phone_number(match.group())
        return None

    def extract_skills(self, text: str) -> List[str]:
        """Extract skills using regex patterns"""
        skills = set()
        text_lower = text.lower()
        
        for pattern in self.skill_patterns:
            matches = re.findall(pattern, text_lower)
            skills.update(matches)
        
        return list(skills)

    def extract_education(self, text: str) -> List[Dict]:
        """Extract education information"""
        education = []
        lines = text.split('\n')
        
        for i, line in enumerate(lines):
            line_lower = line.lower()
            # Check if line contains education-related keywords
            if any(pattern in line_lower for pattern in self.education_patterns):
                education_entry = {
                    'institution': line.strip(),
                    'degree': self.extract_degree(line),
                    'year': self.extract_year(line)
                }
                education.append(education_entry)
        
        return education

    def extract_degree(self, text: str) -> Optional[str]:
        """Extract degree from text"""
        degree_patterns = [
            r'\b(bachelor.*?science|b\.s\.)\b',
            r'\b(bachelor.*?arts|b\.a\.)\b',
            r'\b(master.*?science|m\.s\.)\b',
            r'\b(master.*?arts|m\.a\.)\b',
            r'\b(phd|doctorate)\b'
        ]
        
        for pattern in degree_patterns:
            match = re.search(pattern, text.lower())
            if match:
                return match.group().title()
        return None

    def extract_year(self, text: str) -> Optional[str]:
        """Extract year from text"""
        year_pattern = r'\b(19|20)\d{2}\b'
        match = re.search(year_pattern, text)
        return match.group() if match else None

    def extract_experience(self, text: str) -> List[Dict]:
        """Extract work experience"""
        experience = []
        lines = text.split('\n')
        
        # Look for experience indicators
        exp_keywords = ['experience', 'work', 'employment', 'career']
        current_company = None
        current_position = None
        
        for i, line in enumerate(lines):
            line_clean = line.strip()
            if not line_clean:
                continue
                
            # Check if this might be a company name (simple heuristic)
            if (len(line_clean.split()) <= 5 and 
                any(keyword in line_clean.lower() for keyword in ['inc', 'corp', 'ltd', 'company', 'llc'])):
                current_company = line_clean
            # Check if this might be a position
            elif (current_company and 
                  any(keyword in line_clean.lower() for keyword in ['manager', 'developer', 'engineer', 'analyst', 'specialist'])):
                experience_entry = {
                    'company': current_company,
                    'position': line_clean,
                    'duration': self.extract_duration(lines[i+1] if i+1 < len(lines) else "")
                }
                experience.append(experience_entry)
                current_company = None
        
        return experience

    def extract_duration(self, text: str) -> Optional[str]:
        """Extract employment duration"""
        duration_pattern = r'(\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–]\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}|\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s*\d{4}\s*[-–]\s*(Present|Current))'
        match = re.search(duration_pattern, text, re.IGNORECASE)
        if match:
            # USE THE UTILITY FUNCTION
            return format_duration(match.group())
        return None

    # ADD NEW METHOD FOR SKILL CATEGORIZATION
    def categorize_skills(self, skills: List[str]) -> Dict[str, List[str]]:
        """Categorize skills into domains using utility function"""
        return skill_categorizer(skills)

    # ADD NEW METHOD FOR RESUME SCORING
    def calculate_resume_score(self, parsed_data: Dict) -> int:
        """Calculate resume completeness score"""
        return calculate_resume_score(parsed_data)

    # ADD NEW METHOD FOR EXPERIENCE EXTRACTION
    def extract_years_of_experience(self, text: str) -> int:
        """Extract total years of experience"""
        return extract_years_of_experience(text)

    def parse_resume(self, file_path: str) -> Dict:
        """Main method to parse resume and return structured data"""
        try:
            # Extract and clean text
            raw_text = self.extract_text(file_path)
            cleaned_text = self.clean_text(raw_text)
            
            # Extract various components
            parsed_data = {
                'personal_info': {
                    'name': self.extract_name(cleaned_text),
                    'email': self.extract_email(cleaned_text),
                    'phone': self.extract_phone(cleaned_text)
                },
                'skills': self.extract_skills(cleaned_text),
                'education': self.extract_education(cleaned_text),
                'experience': self.extract_experience(cleaned_text),
                'raw_text_preview': cleaned_text[:500] + "..." if len(cleaned_text) > 500 else cleaned_text
            }
            
            # ADD ENHANCED DATA USING UTILS
            parsed_data['skill_categories'] = self.categorize_skills(parsed_data['skills'])
            parsed_data['resume_score'] = self.calculate_resume_score(parsed_data)
            parsed_data['years_experience'] = self.extract_years_of_experience(cleaned_text)
            
            return parsed_data
            
        except Exception as e:
            return {'error': str(e)}

    def to_json(self, parsed_data: Dict) -> str:
        """Convert parsed data to JSON"""
        return json.dumps(parsed_data, indent=2)

    def to_dataframe(self, parsed_data: Dict) -> pd.DataFrame:
        """Convert parsed data to pandas DataFrame"""
        # Flatten the data for tabular representation
        flat_data = {
            'Name': parsed_data['personal_info']['name'],
            'Email': parsed_data['personal_info']['email'],
            'Phone': parsed_data['personal_info']['phone'],
            'Skills': ', '.join(parsed_data['skills']),
            'Education_Count': len(parsed_data['education']),
            'Experience_Count': len(parsed_data['experience']),
            # ADD NEW FIELDS
            'Resume_Score': parsed_data.get('resume_score', 0),
            'Years_Experience': parsed_data.get('years_experience', 0)
        }
        return pd.DataFrame([flat_data])