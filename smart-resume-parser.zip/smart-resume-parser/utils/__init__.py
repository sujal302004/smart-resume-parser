"""
Utility functions for Smart Resume Parser
"""

# This file makes the utils directory a Python package
# You can add utility functions here or import them from other modules
from typing import Optional

import re
import json
from typing import List, Dict, Any
import pandas as pd 

def clean_phone_number(phone: str) -> str:
    """
    Clean and standardize phone number format
    """
    if not phone:
        return ""
    
    # Remove all non-digit characters except +
    cleaned = re.sub(r'[^\d+]', '', phone)
    
    # Format as (XXX) XXX-XXXX if it's 10 digits
    if len(cleaned) == 10:
        return f"({cleaned[:3]}) {cleaned[3:6]}-{cleaned[6:]}"
    elif len(cleaned) == 11 and cleaned.startswith('1'):
        return f"+1 ({cleaned[1:4]}) {cleaned[4:7]}-{cleaned[7:]}"
    
    return phone

def validate_email(email: str) -> bool:
    """
    Validate email format
    """
    if not email:
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def extract_years_of_experience(text: str) -> int:
    """
    Extract years of experience from text
    """
    patterns = [
        r'(\d+)\+?\s*years?',
        r'(\d+)\+?\s*yrs?',
        r'(\d+)\+?\s*experience'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text.lower())
        if match:
            return int(match.group(1))
    
    return 0

def skill_categorizer(skills: List[str]) -> Dict[str, List[str]]:
    """
    Categorize skills into different domains
    """
    skills = skills or []  # Handle None case
    
    categories = {
        'programming': [],
        'web_development': [],
        'data_science': [],
        'devops': [],
        'databases': [],
        'soft_skills': [],
        'tools': []
    }
    
    skill_mapping = {
        'programming': ['python', 'java', 'c++', 'c#', 'javascript', 'typescript', 'go', 'rust', 'swift', 'kotlin'],
        'web_development': ['html', 'css', 'react', 'angular', 'vue', 'node.js', 'django', 'flask', 'express'],
        'data_science': ['machine learning', 'deep learning', 'tensorflow', 'pytorch', 'pandas', 'numpy', 'scikit-learn'],
        'devops': ['aws', 'azure', 'gcp', 'docker', 'kubernetes', 'jenkins', 'terraform', 'ansible'],
        'databases': ['mysql', 'postgresql', 'mongodb', 'redis', 'sqlite', 'oracle'],
        'tools': ['git', 'github', 'gitlab', 'jira', 'confluence', 'vscode', 'pycharm']
    }
    
    for skill in skills:
        skill_lower = skill.lower()
        categorized = False
        
        for category, keywords in skill_mapping.items():
            if any(keyword in skill_lower for keyword in keywords):
                categories[category].append(skill)
                categorized = True
                break
        
        # If not categorized, put in programming by default for technical skills
        if not categorized and any(tech in skill_lower for tech in ['script', 'sql', 'cloud', 'dev']):
            categories['programming'].append(skill)
        elif not categorized:
            categories['soft_skills'].append(skill)
    
    return categories

def calculate_resume_score(parsed_data: Dict[str, Any]) -> int:
    """
    Calculate a resume completeness score (0-100)
    """
    score = 0
    
    # Personal info (20 points)
    personal_info = parsed_data.get('personal_info', {})
    if personal_info.get('name'):
        score += 5
    if personal_info.get('email'):
        score += 5
    if personal_info.get('phone'):
        score += 5
    if personal_info.get('name') and personal_info.get('email') and personal_info.get('phone'):
        score += 5
    
    # Skills (25 points)
    skills = parsed_data.get('skills', [])
    if len(skills) >= 10:
        score += 25
    elif len(skills) >= 5:
        score += 15
    elif len(skills) >= 3:
        score += 10
    elif len(skills) > 0:
        score += 5
    
    # Education (20 points)
    education = parsed_data.get('education', [])
    if len(education) >= 2:
        score += 20
    elif len(education) >= 1:
        score += 15
    elif len(education) > 0:
        score += 10
    
    # Experience (35 points)
    experience = parsed_data.get('experience', [])
    if len(experience) >= 3:
        score += 35
    elif len(experience) >= 2:
        score += 25
    elif len(experience) >= 1:
        score += 15
    elif len(experience) > 0:
        score += 10
    
    return min(score, 100)

def format_duration(duration: str) -> Optional[str]:
    """
    Format employment duration consistently
    """
    if not duration:
        return ""
    
    # Standardize date formats
    duration = duration.replace('–', '-')  # Replace en dash with hyphen
    duration = re.sub(r'\s+', ' ', duration)  # Remove extra spaces
    
    # Convert months to abbreviations
    month_map = {
        'january': 'Jan', 'february': 'Feb', 'march': 'Mar', 'april': 'Apr',
        'may': 'May', 'june': 'Jun', 'july': 'Jul', 'august': 'Aug',
        'september': 'Sep', 'october': 'Oct', 'november': 'Nov', 'december': 'Dec'
    }
    
    for full, abbr in month_map.items():
        duration = duration.lower().replace(full, abbr)
    
    return duration.title()

def export_to_excel(parsed_data_list: List[Dict], filename: str) -> str:
    """
    Export multiple parsed resumes to Excel format
    """
    if not parsed_data_list:
        return ""
    
    # Create a comprehensive DataFrame
    rows = []
    for data in parsed_data_list:
        row = {
            'Filename': data.get('filename', 'Unknown'),
            'Name': data['personal_info'].get('name', ''),
            'Email': data['personal_info'].get('email', ''),
            'Phone': data['personal_info'].get('phone', ''),
            'Skills_Count': len(data.get('skills', [])),
            'Skills': ', '.join(data.get('skills', [])),
            'Education_Count': len(data.get('education', [])),
            'Experience_Count': len(data.get('experience', [])),
            'Resume_Score': calculate_resume_score(data)
        }
        rows.append(row)
    
    df = pd.DataFrame(rows)
    
    try:
        # Save to Excel with multiple sheets
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            # Summary sheet
            df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Detailed skills sheet
            skills_data = []
            for data in parsed_data_list:
                for skill in data.get('skills', []):
                    skills_data.append({
                        'Name': data['personal_info'].get('name', 'Unknown'),
                        'Skill': skill,
                        'Category': next((cat for cat, skills in skill_categorizer([skill]).items() if skills), 'Other')
                    })
            
            if skills_data:
                skills_df = pd.DataFrame(skills_data)
                skills_df.to_excel(writer, sheet_name='Skills_Detail', index=False)
        
        return filename
    except Exception as e:
        # Fallback to CSV if Excel fails
        csv_filename = filename.replace('.xlsx', '.csv')
        df.to_csv(csv_filename, index=False)
        return csv_filename

def safe_string_conversion(text: Any) -> str:
    """
    Safely convert any value to string, handling None and special characters
    """
    if text is None:
        return ""
    
    try:
        return str(text).encode('utf-8', 'ignore').decode('utf-8')
    except:
        return ""

def extract_company_from_email(email: str) -> str:
    """
    Extract company name from email domain
    """
    if not email or '@' not in email:
        return ""
    
    domain = email.split('@')[1].split('.')[0]
    
    # Common domain to company mappings
    domain_map = {
        'gmail': 'Personal',
        'yahoo': 'Personal',
        'outlook': 'Personal',
        'hotmail': 'Personal'
    }
    
    return domain_map.get(domain, domain.title())

# Add missing import
from typing import Optional

# Version information
__version__ = "1.0.0"
__author__ = "Smart Resume Parser Team"
__description__ = "Utility functions for resume parsing and data processing"

# Export specific functions for easier imports
__all__ = [
    'clean_phone_number',
    'validate_email',
    'extract_years_of_experience',
    'skill_categorizer',
    'calculate_resume_score',
    'format_duration',
    'export_to_excel',
    'safe_string_conversion',
    'extract_company_from_email'
]